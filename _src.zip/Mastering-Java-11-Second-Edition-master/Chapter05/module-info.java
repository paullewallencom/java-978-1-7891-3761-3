module com.three19.irisScan 
{
// modules that com.three19.irisScan depends upon
requires com.three19.irisCore;
requires com.three19.irisData;

// export packages for other modules that are dependent upon com.three19.irisScan
exports com.three19.irisScan.biometric;
}