
public class Underscore {

	public static void main(String[] args) 
	{
		Object _ = new Object();
		
		System.out.println("This ran successfully.");
		

	}

}
